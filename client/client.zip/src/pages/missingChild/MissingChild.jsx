import React from 'react'
import FbNavbar from '../../components/fbnavbar/FbNavbar'

const MissingChild = () => {
  return (
    <>
     <FbNavbar/>
    </>
  )
}

export default MissingChild