import React from 'react'
import DonationCh from '../../components/donationCh/DonationCh'



const Donation = () => {
  return (
    <>
  
    
    <DonationCh/>
    </>
  )
}

export default Donation