import axios from "axios";
import { useEffect,useState } from "react";

const useFetch = (url) =>{
    const [data , setData] = useState([])
    const [error , setError] = useState(false)
    const [loading, setLoading] = useState(false)

    useEffect(()=>{
        const fetchData = async ()=>{
            setLoading(true);
            try{
                const res = await axios.get(url)
                console.log(res)
                setData(res.data);
            }catch(err){
            setError(err);
            }
            setLoading(false);
        };
        fetchData();
    },[url]);

    return{data,error,loading}
};

export default useFetch;