import React from 'react'

const DonutChart = () => {
  return (
    <div>DonutChart</div>
    
  )
}

export default DonutChart