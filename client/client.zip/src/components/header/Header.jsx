import React from 'react'
import FbNavbar from '../fbnavbar/FbNavbar'


const Header = () => {
  return (
    <div>
      <FbNavbar/>
    </div>
  )
}

export default Header