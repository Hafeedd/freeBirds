import React from 'react'

const mail = () => {
  return (
    <div>mail</div>
  )
}

export default mail