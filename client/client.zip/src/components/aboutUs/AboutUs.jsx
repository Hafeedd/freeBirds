import React from 'react'

const AboutUs = () => {
  return (
    <div className='shadow'>
        
    </div>
  )
}

export default AboutUs